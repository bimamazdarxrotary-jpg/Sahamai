# SahamAI — Struktur & Status File

## Ringkasan
- Total file: 30
- Diubah: 25 ✅
- Tidak diubah: 5 ⬜
- Rata-rata rating: 9.1/10

---

## 📁 api/
| File Output | Lokasi Project | Rating | Status |
|-------------|----------------|--------|--------|
| `outputs/analyze.js` | `api/analyze.js` | 9.5/10 | ✅ Diubah |
| `outputs/scanner.js` | `api/scanner.js` | 9.5/10 | ✅ Diubah |
| `outputs/health.js` | `api/health.js` | 9/10 | ✅ Diubah |

## 📁 lib/
| File Output | Lokasi Project | Rating | Status |
|-------------|----------------|--------|--------|
| `outputs/indicators.js` | `lib/indicators.js` | 9.5/10 | ✅ Diubah |
| `outputs/scoring.js` | `lib/scoring.js` | 9.5/10 | ✅ Diubah |
| `outputs/ai.js` | `lib/ai.js` | 9.5/10 | ✅ Diubah |
| `outputs/lib_scanner.js` | `lib/scanner.js` | 9.5/10 | ✅ Diubah |
| `outputs/structure.js` | `lib/structure.js` | 9/10 | ✅ Diubah |
| `outputs/volume.js` | `lib/volume.js` | 9/10 | ✅ Diubah |
| `outputs/bandar.js` | `lib/bandar.js` | 9/10 | ✅ Diubah |
| `outputs/context.js` | `lib/context.js` | 9/10 | ✅ Diubah |
| `outputs/validation.js` | `lib/validation.js` | 9/10 | ✅ Diubah |
| `outputs/news.js` | `lib/news.js` | 8/10 | ✅ Diubah |
| *(tidak diubah)* | `lib/cache.js` | 9/10 | ⬜ Tidak diubah |
| *(tidak diubah)* | `lib/logger.js` | 8.5/10 | ⬜ Tidak diubah |

## 📁 public/
| File Output | Lokasi Project | Rating | Status |
|-------------|----------------|--------|--------|
| `outputs/index.html` | `public/index.html` | 9/10 | ✅ Diubah |
| `outputs/app.js` | `public/app.js` | 8.5/10 | ✅ Diubah |

## 📁 data/
| File Output | Lokasi Project | Rating | Status |
|-------------|----------------|--------|--------|
| `outputs/idx-stocks.json` | `data/idx-stocks.json` | 9.5/10 | ✅ Diubah |

## 📁 tests/
| File Output | Lokasi Project | Rating | Status |
|-------------|----------------|--------|--------|
| `outputs/volume_test.js` | `tests/volume.test.js` | 9.5/10 | ✅ Diubah |
| `outputs/context_test.js` | `tests/context.test.js` | 9.5/10 | ✅ Diubah |
| `outputs/structure_test.js` | `tests/structure.test.js` | 9.5/10 | ✅ Diubah |
| `outputs/bandar_test.js` | `tests/bandar.test.js` | 9/10 | ✅ Diubah |
| *(tidak diubah)* | `tests/indicators.test.js` | 9/10 | ⬜ Tidak diubah |
| *(tidak diubah)* | `tests/scoring.test.js` | 9/10 | ⬜ Tidak diubah |
| *(tidak diubah)* | `tests/run.js` | 8.5/10 | ⬜ Tidak diubah |

## 📁 root/
| File Output | Lokasi Project | Rating | Status |
|-------------|----------------|--------|--------|
| `outputs/vercel.json` | `vercel.json` | 9.5/10 | ✅ Diubah |
| `outputs/package.json` | `package.json` | 9/10 | ✅ Diubah |
| `outputs/README.md` | `README.md` | 8.5/10 | ✅ Diubah |
| `outputs/_env.example` | `.env.example` | 9.5/10 | ✅ Diubah |
| `outputs/server.js` | `server.js` | 9/10 | ✅ Diubah |

---

## 🗂️ Struktur Folder Project Lengkap

```
sahamai/
├── api/
│   ├── analyze.js        ← outputs/analyze.js        (9.5/10) ✅
│   ├── scanner.js        ← outputs/scanner.js         (9.5/10) ✅
│   └── health.js         ← outputs/health.js          (9.0/10) ✅
├── data/
│   └── idx-stocks.json   ← outputs/idx-stocks.json   (9.5/10) ✅
├── lib/
│   ├── ai.js             ← outputs/ai.js              (9.5/10) ✅
│   ├── indicators.js     ← outputs/indicators.js      (9.5/10) ✅
│   ├── scanner.js        ← outputs/lib_scanner.js     (9.5/10) ✅
│   ├── scoring.js        ← outputs/scoring.js         (9.5/10) ✅
│   ├── structure.js      ← outputs/structure.js       (9.0/10) ✅
│   ├── volume.js         ← outputs/volume.js          (9.0/10) ✅
│   ├── bandar.js         ← outputs/bandar.js          (9.0/10) ✅
│   ├── context.js        ← outputs/context.js         (9.0/10) ✅
│   ├── validation.js     ← outputs/validation.js      (9.0/10) ✅
│   ├── news.js           ← outputs/news.js            (8.0/10) ✅
│   ├── cache.js          ← (tidak diubah)             (9.0/10) ⬜
│   └── logger.js         ← (tidak diubah)             (8.5/10) ⬜
├── public/
│   ├── index.html        ← outputs/index.html         (9.0/10) ✅
│   └── app.js            ← outputs/app.js             (8.5/10) ✅
├── tests/
│   ├── volume.test.js    ← outputs/volume_test.js     (9.5/10) ✅
│   ├── context.test.js   ← outputs/context_test.js    (9.5/10) ✅
│   ├── structure.test.js ← outputs/structure_test.js  (9.5/10) ✅
│   ├── bandar.test.js    ← outputs/bandar_test.js     (9.0/10) ✅
│   ├── indicators.test.js← (tidak diubah)             (9.0/10) ⬜
│   ├── scoring.test.js   ← (tidak diubah)             (9.0/10) ⬜
│   └── run.js            ← (tidak diubah)             (8.5/10) ⬜
├── .env.example          ← outputs/_env.example       (9.5/10) ✅
├── package.json          ← outputs/package.json       (9.0/10) ✅
├── README.md             ← outputs/README.md          (8.5/10) ✅
├── server.js             ← outputs/server.js          (9.0/10) ✅
└── vercel.json           ← outputs/vercel.json        (9.5/10) ✅
```

---

## 📝 Catatan Penting

### Rename yang diperlukan saat deploy:
| Nama Output | Rename Menjadi |
|-------------|----------------|
| `lib_scanner.js` | `scanner.js` (taruh di `lib/`) |
| `_env.example` | `.env.example` |
| `volume_test.js` | `volume.test.js` |
| `context_test.js` | `context.test.js` |
| `structure_test.js` | `structure.test.js` |
| `bandar_test.js` | `bandar.test.js` |
| `indicators_test.js` | `indicators.test.js` |
| `scoring_test.js` | `scoring.test.js` |

### File tidak perlu diubah:
- `lib/cache.js`
- `lib/logger.js`
- `tests/indicators.test.js`
- `tests/scoring.test.js`
- `tests/run.js`
